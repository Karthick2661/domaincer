import React from "react";
import { Link } from "react-router-dom";
import './header.css'
import './Greeting.css'
import './contact.css'
import { Fade } from "react-reveal";

import Headroom from "react-headroom";



function Landingpage() {

  return <>

    <Headroom>
      <header className="header">
        <a href="#" className="logo">
          <span className="grey-color"> </span>
          <span className="logo-name">Jobs</span>
          <span className="grey-color"></span>
        </a>
        <input className="menu-btn" type="checkbox" id="menu-btn" />
        <label className="menu-icon" htmlFor="menu-btn">
          <span className="navicon"></span>
        </label>
        <ul className="menu">
        <Link to="/login">
          <li>
            <a>Login</a>
           
          </li>
          </Link>
          <Link to="/signup">
          <li>
            <a>Signup</a>
           
          </li>
          </Link>
        </ul>
      </header>
    </Headroom>
    <Fade bottom duration={1000} distance="40px">
      <div className="greet-main" id="greeting">
        <div className="greeting-main">
          <div className="greeting-text-div">
            <div>
              <h1 className="greeting-text" id="type">
                {" "}
                <span>Jobportal</span>

                {" "}

              </h1>
              <p className="greeting-text-p subTitle">Get recruited</p>

             
            </div>
          </div>
        </div>
      </div>
    </Fade>
    <Fade bottom duration={1000} distance="20px">
     
        
    </Fade>
    <Fade bottom duration={1000} distance="5px">
      <div className="footer-div">
       
      </div>
    </Fade>

  </>
}
export default Landingpage;