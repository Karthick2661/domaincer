const apiUrl = 'http://localhost:5000';

export {  apiUrl };